
  # Knowledge Management Tool

  This is a code bundle for Knowledge Management Tool. The original project is available at https://www.figma.com/design/rQHlQYylU5tElMEUnX5buY/Knowledge-Management-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  